create function archive_usage_logs_weekly() returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO usage_logs_weekly SELECT * FROM usage_logs WHERE created_at < NOW() - INTERVAL '1 week';
    DELETE FROM usage_logs WHERE created_at < NOW() - INTERVAL '1 week';
END;
$$;

alter function archive_usage_logs_weekly() owner to postgres;

