create function fn_update_quota() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE users SET used_quota = used_quota + NEW.amount WHERE id = NEW.user_id;
    WITH RECURSIVE chain AS (
        SELECT id, parent_reseller_id FROM resellers WHERE id = NEW.reseller_id
        UNION ALL
        SELECT r.id, r.parent_reseller_id FROM resellers r JOIN chain c ON r.id = c.parent_reseller_id
    )
    UPDATE resellers SET used_quota = used_quota + NEW.amount FROM chain WHERE resellers.id = chain.id;
    UPDATE servers SET used_quota = used_quota + NEW.amount WHERE id = NEW.server_id;
    RETURN NEW;
END;
$$;

alter function fn_update_quota() owner to postgres;

