create function archive_usage_logs_hourly() returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO usage_logs_hourly SELECT * FROM usage_logs WHERE created_at < NOW() - INTERVAL '1 hour';
    DELETE FROM usage_logs WHERE created_at < NOW() - INTERVAL '1 hour';
END;
$$;

alter function archive_usage_logs_hourly() owner to postgres;

