create function archive_usage_logs_monthly() returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO usage_logs_monthly SELECT * FROM usage_logs WHERE created_at < NOW() - INTERVAL '1 month';
    DELETE FROM usage_logs WHERE created_at < NOW() - INTERVAL '1 month';
END;
$$;

alter function archive_usage_logs_monthly() owner to postgres;

