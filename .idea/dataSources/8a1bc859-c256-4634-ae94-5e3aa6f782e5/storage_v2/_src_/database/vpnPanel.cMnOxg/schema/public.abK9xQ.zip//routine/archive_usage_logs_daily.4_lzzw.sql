create function archive_usage_logs_daily() returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO usage_logs_daily SELECT * FROM usage_logs WHERE created_at < NOW() - INTERVAL '1 day';
    DELETE FROM usage_logs WHERE created_at < NOW() - INTERVAL '1 day';
END;
$$;

alter function archive_usage_logs_daily() owner to postgres;

